<?php $__env->startSection('content'); ?>
    <div class="container" style="height: auto;">
        <div class="row justify-content-center">
            <div class="col-lg-12 col-md-8">

                <main>

                    <div class="container marketing">
                        <div class="container">
                            <div class="row row-cols-2">
                                <div class="col-4" style="border-right-style: solid;border-right-color: #aaaaaa;border-right-width: 2px;">
                                    <h5>Product Categories</h5>
                                    <ul class="list-group list-group-flush">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <a href="<?php echo e(url('/all-products/'.$c->id)); ?>" style="font-size: 0.9em;text-decoration: none; cursor: pointer;" class="text-primary">
                                                    <?php echo e($c->name); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>

                                </div>


























                                <div class="col-8">
                                    <div class="row bg-white g-1 my-5 mx-1">
                                        <h1 class="text-danger p-lg-5 m-5">Under Construction</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </main>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'off-canvas-sidebar', 'activePage' => 'catalogue', 'title' => __('Catalogue')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/efarmersmarket/resources/views/catalogue/index.blade.php ENDPATH**/ ?>