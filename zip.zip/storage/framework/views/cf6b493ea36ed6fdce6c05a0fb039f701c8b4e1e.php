<footer class="footer">
    <div class="container">
        <nav class="float-left">

        </nav>
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, HIT 400 Capstone Project
        </div>
    </div>
</footer>
<?php /**PATH /opt/lampp/htdocs/efarmersmarket/resources/views/layouts/footers/guest.blade.php ENDPATH**/ ?>